import React, { useState } from 'react';
import axios from 'axios';
import './Chat.css';

function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const fetchReply = async (message) => {
    try {
    	const apiKey = process.env.apiKey;
      const payload = {
        contents: [
          {
            parts: [
              {
                text: message
              }
            ]
          }
        ]
      };

      console.log("Sending payload to API:", JSON.stringify(payload));

      const { data } = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key= AIzaSyBqbDEt3ZPsBuCMvo3oDBz6h6x9CcxVyTM`, 
        payload
      );
      
      console.log("API response:", data);

      if (data && data.candidates && data.candidates.length > 0) {
        const botResponse = data.candidates[0].content.parts[0].text;
        setMessages(prevMessages => [
          ...prevMessages,
          { text: message, sender: 'user' },
          { text: botResponse, sender: 'bot' }
        ]);
      } else {
        console.error("Invalid response structure:", data);
      }
    } catch (error) {
      console.error("Error fetching reply:", error);
    }
  };


  const handleSend = () => {
    if (input.trim() === '') return;

    setMessages(prevMessages => [...prevMessages, { text: input, sender: 'user' }]);
    fetchReply(input);
    setInput('');
  };

  return (
    <div className="chat-container">
      <h2>Meliora</h2>
      {messages.map((message, index) => (
        <p key={index}><strong>{message.sender}:</strong> {message.text}</p>
      ))}
   
      <textarea value={input} onChange={e => setInput(e.target.value)} />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}

export default Chat;

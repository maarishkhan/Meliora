package com.aarish.chatbot;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.util.Collections;

@RestController
@RequestMapping("/api")
public class ChatController {
    private boolean responseReturned = false;

    @PostMapping("/chat")
    public ResponseEntity<String> chat(@RequestBody ChatRequest chatRequest) {
        if (responseReturned) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body("Response already returned");
        }

        responseReturned = true;
        System.out.print(chatRequest);
        RestTemplate restTemplate = new RestTemplate();
        String apiKey = getBardApiKey();
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyBqbDEt3ZPsBuCMvo3oDBz6h6x9CcxVyTM";
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        
        // Build request parameters
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("key", apiKey);

        // Send the chatRequest directly in the request body
        HttpEntity<ChatRequest> entity = new HttpEntity<>(chatRequest, headers);
        
        ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity, String.class);
        if (response.getStatusCode() != HttpStatus.OK) {
            responseReturned = false;
        }
        
        return response;
    }

    private String getBardApiKey() {
        return "AIzaSyBqbDEt3ZPsBuCMvo3oDBz6h6x9CcxVyTM";//actual retrieval logic
    }
}
